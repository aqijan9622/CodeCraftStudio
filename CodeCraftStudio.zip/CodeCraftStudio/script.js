const $ = (id) => document.getElementById(id);

const starterFiles = {
  "index.html": `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Website</title>
</head>
<body>
  <main class="welcome">
    <h1>Hello, CodeCraft!</h1>
    <p>Your live preview is working!</p>
    <button id="helloBtn">Click me</button>
    <p id="message"></p>
  </main>
</body>
</html>`,
  "style.css": `body {
  margin: 0;
  font-family: Arial, sans-serif;
  background: #f4f5ff;
  color: #24243a;
}
.welcome {
  max-width: 700px;
  margin: 80px auto;
  padding: 32px;
  text-align: center;
  background: white;
  border-radius: 18px;
}
h1 { color: #7159d9; }
button {
  padding: 12px 22px;
  border: 0;
  border-radius: 8px;
  background: #7159d9;
  color: white;
  cursor: pointer;
}`,
  "script.js": `document.getElementById("helloBtn")?.addEventListener("click", () => {
  document.getElementById("message").textContent =
    "Your JavaScript is working!";
});`
};

let files = { ...starterFiles };
let activeFile = null;
let previewTimer;

const editor = $("codeEditor");
const list = $("fileList");
const tabs = $("tabsBar");
const frame = $("previewFrame");

function status(message, error = false) {
  const el = $("status");
  if (el) {
    el.textContent = message;
    el.className = "status" + (error ? " error" : "");
  }
}

function saveCurrent() {
  if (editor && activeFile && Object.hasOwn(files, activeFile)) {
    files[activeFile] = editor.value;
  }
}

function render() {
  if (!list || !tabs) return;

  list.replaceChildren();
  tabs.replaceChildren();

  Object.keys(files).forEach((name) => {
    const row = document.createElement("div");
    row.className = "file-item" + (name === activeFile ? " active" : "");

    const icon = document.createElement("span");
    icon.className = "file-icon";
    icon.textContent = name.endsWith(".html") ? "🌐" :
      name.endsWith(".css") ? "🎨" :
      name.endsWith(".js") ? "🟨" : "📄";

    const label = document.createElement("span");
    label.className = "file-name";
    label.textContent = name;

    row.append(icon, label);
    row.addEventListener("click", () => openFile(name));
    list.appendChild(row);

    if (name === activeFile) {
      const tab = document.createElement("div");
      tab.className = "file-tab active";
      tab.textContent = name;
      tabs.appendChild(tab);
    }
  });

  if ($("editorFileLabel")) {
    $("editorFileLabel").textContent = activeFile || "No file selected";
  }

  const extension = activeFile?.split(".").pop() || "text";
  if ($("editorLanguage")) {
    $("editorLanguage").textContent =
      ({ html: "HTML", css: "CSS", js: "JAVASCRIPT" })[extension] || "TEXT";
  }
}

function openFile(name) {
  if (!Object.hasOwn(files, name)) return;
  saveCurrent();
  activeFile = name;
  editor.value = files[name];
  render();
  updatePreview();
}

function updatePreview() {
  if (!frame) return;
  saveCurrent();

  let html = files["index.html"] || "<h1>Create index.html</h1>";
  const css = files["style.css"] || "";
  const js = files["script.js"] || "";

  const style = `<style>${css}</style>`;
  const script = `<script>${js}<\/script>`;

  if (/<head\b[^>]*>/i.test(html)) {
    html = html.replace(/<\/head\s*>/i, `${style}</head>`);
  } else {
    html = `<head>${style}</head>${html}`;
  }

  if (/<\/body\s*>/i.test(html)) {
    html = html.replace(/<\/body\s*>/i, `${script}</body>`);
  } else {
    html += script;
  }

  frame.srcdoc = html;
}

function schedulePreview() {
  clearTimeout(previewTimer);
  previewTimer = setTimeout(updatePreview, 250);
}

if (editor) {
  editor.addEventListener("input", () => {
    saveCurrent();
    schedulePreview();
  });

  editor.addEventListener("keydown", (event) => {
    if (event.key === "Tab") {
      event.preventDefault();
      editor.setRangeText(
        "  ",
        editor.selectionStart,
        editor.selectionEnd,
        "end"
      );
      saveCurrent();
      schedulePreview();
    }
  });
}

$("newFileBtn")?.addEventListener("click", () => {
  const name = prompt("File name, e.g. about.html");
  if (!name) return;

  const filename = name.trim();

  if (!/^[\w.-]+\.(html|css|js|json|txt)$/i.test(filename)) {
    alert("Use a filename ending in .html, .css, .js, .json or .txt");
    return;
  }

  if (Object.hasOwn(files, filename)) {
    alert("This file already exists.");
    return;
  }

  saveCurrent();
  files[filename] = "";
  openFile(filename);
  status("Created " + filename);
});

const modes = {
  desktop: ["desktop-frame", "Desktop · Full width"],
  tablet: ["tablet-frame", "Tablet"],
  mobile: ["mobile-frame", "Mobile"]
};

document.querySelectorAll(".device-btn").forEach((button) => {
  button.addEventListener("click", () => {
    const mode = modes[button.dataset.device];
    if (!mode) return;

    $("deviceFrame").className = "device-frame " + mode[0];
    $("deviceLabel").textContent = mode[1];

    document.querySelectorAll(".device-btn").forEach((item) => {
      item.classList.toggle("active", item === button);
    });

    updatePreview();
  });
});

$("refreshPreviewBtn")?.addEventListener("click", updatePreview);

$("downloadBtn")?.addEventListener("click", async () => {
  saveCurrent();

  if (!window.JSZip) {
    status("ZIP library failed to load. Check your internet.", true);
    return;
  }

  try {
    const zip = new window.JSZip();

    Object.entries(files).forEach(([name, content]) => {
      zip.file(name, content);
    });

    const blob = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = (($("projectName")?.value.trim()) || "my-project") + ".zip";
    link.click();

    setTimeout(() => URL.revokeObjectURL(url), 1000);
    status("ZIP downloaded successfully.");
  } catch (error) {
    status("Download failed: " + error.message, true);
  }
});

render();
openFile("index.html");
status("Ready — live preview enabled.");